/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.HireApplications;

import java.util.ArrayList;

/**
 *
 * @author sanket
 */
public class NewHireApplicationsDirectory {
    
    private ArrayList<NewHireApplication> newHireApplication;
    
    public NewHireApplicationsDirectory () {
        this.newHireApplication = newHireApplication;
    }

    public ArrayList<NewHireApplication> getNewHireApplication() {
        return newHireApplication;
    }

    public void setNewHireApplication(ArrayList<NewHireApplication> newHireApplication) {
        this.newHireApplication = newHireApplication;
    }
    
    
}
