/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author shreya
 */
public class ProductAvailabilityQueue {
    private ArrayList<ProductAvailabilityQueue> productAvailabilityList;
    
    public ProductAvailabilityQueue(){
        this.productAvailabilityList = productAvailabilityList;
    }

    public ArrayList<ProductAvailabilityQueue> getProductAvailabilityList() {
        return productAvailabilityList;
    }

    public void setProductAvailabilityList(ArrayList<ProductAvailabilityQueue> productAvailabilityList) {
        this.productAvailabilityList = productAvailabilityList;
    } 
}
