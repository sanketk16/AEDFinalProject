/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Business.Product;


import java.util.ArrayList;

/**
 *
 * @author sanket
 */
public class ProductFleet {
    private ArrayList<ProductFleet> productFleet;
    
    public ProductFleet(){
        this.productFleet = productFleet;
    }

    public ArrayList<ProductFleet> getProductFleet() {
        return productFleet;
    }

    public void setProductFleet(ArrayList<ProductFleet> productFleet) {
        this.productFleet = productFleet;
    }
}
